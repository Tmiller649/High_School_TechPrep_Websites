<?php

$servername = "gator3272.hostgator.com";
$dataBaseUser = "it_tale";
$dataBasePass = "BzvoMDg.7NcS";
$dataBaseName = "it_webapplication";

$connect = mysqli_connect($servername, $dataBaseUser, $dataBasePass, $dataBaseName);
