</main>
<footer>
	<p>Region 19: Luis Avina, Evan Difilipio, Terrance Miller, Abraham Dereje<p>
	<p><i>Today’s students. Tomorrow’s business professionals.</i></p>
</footer>

</body>
</html>