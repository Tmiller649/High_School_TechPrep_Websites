<?php

$servername = "localhost";
$dataBaseUser = "root";
$dataBasePass = "";
$dataBaseName = "techPrep";
// Connects the website to the database
$connect = mysqli_connect($servername, $dataBaseUser, $dataBasePass, $dataBaseName);
