<?php
	require 'dataBaseHandler.php';
?>

<!Doctype html>
<html>
<head>
   <meta charset="utf-8">
   <meta name="keywords" content="gluten, gluten free, sinfully gluten, sinfully, centerville food" />
   <meta name="viewport" content="width=device-width, initial-scale=1" />
   <title>Sinfully Gluten-Free</title>
   <link href="Base.css" rel="stylesheet" />
</head>
<header>
<body>
<img src ="images/SGlogo.jpg" style="width: 30%"> 
<br>
<!-- links to other pages -->
<span id ="link">
 <a href="Home.php">Home</a> |
 <a href="Menu.php">Menu</a> | 
 <a href="Review.php">Review</a> | 
 <a href="Contact.php">Contact</a> | 
 <a href="AboutUs.php">About Us</a>
 </span>
 </header>
 <br>
 <hr>