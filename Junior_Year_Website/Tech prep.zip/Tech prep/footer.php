<br>
<hr>
<!-- links for social media's and other infor -->
<footer>
  <b>Follow us on social media</b><a href="https://twitter.com/intent/tweet?text=Home&url=http%3A%2F%2Fwww.sinfullygf.com%2F&related="><img src="images/twitter.png" style="width:4%"></a>
  <a href="https://www.facebook.com/SinfullyGlutenFree/"><img src="images/facebook.png" style="width:4%"></a>
<p><address><b>9146 Dayton Lebanon Pike, Dayton, OH 45458<b></address></p>
<p>(937) 433-1044 </p>
</footer>
</div>
</body>
</html>